<?php

/**
 *
 * Copyright © 2023 PagoNxt Merchant Solutions S.L. German Branch
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0
 *
 */

if (!function_exists('dump')) {
    function dump($var)
    {
        if (!is_string($var)) {
            $var = json_encode($var);
        }
        var_dump($var);
        error_log($var);
    }
}

if (!function_exists('dumpExit')) {
    function dumpExit($var)
    {
        if (!is_string($var)) {
            $var = json_encode($var);
        }
        var_dump($var);
        error_log($var);
        exit(0);
    }
}

/**
 * Fetch full url
 *
 * @param array $s
 * @param boolean $use_forwarded_host
 * @return string
 */
function fullUrl($use_forwarded_host = false)
{
    return urlOrigin($_SERVER, $use_forwarded_host) . $_SERVER['REQUEST_URI'];
}

/**
 * Fetch url origin
 *
 * @param array $s
 * @param boolean $use_forwarded_host
 * @return string
 */
function urlOrigin($s, $use_forwarded_host = false)
{
    $ssl = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on');
    $sp = strtolower($s['SERVER_PROTOCOL']);
    $protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
    $port = $s['SERVER_PORT'];
    $port = ((!$ssl && $port == '80') || ($ssl && $port == '443')) ? '' : ':' . $port;
    $host = ($use_forwarded_host && isset($s['HTTP_X_FORWARDED_HOST'])) ? $s['HTTP_X_FORWARDED_HOST'] : (isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : null);
    $host = isset($host) ? $host : $s['SERVER_NAME'] . $port;
    return $protocol . '://' . $host;
}

/**
 * Generate the note from the transaction response
 *
 * @param mixed $response
 * @param boolean $with_code
 * @return string
 */
function getNoteFromTransactionResponse($response, $with_code)
{
    $note = null;
    $requestId = $response['payment']['request-id'];

    if (str_contains($response['payment']['request-id'], '-')) {
        $arrayBody = explode("-", $requestId);
        $requestId  = $arrayBody[0];
    }

    if (
        array_key_exists('request-id', $response['payment']) &&
        array_key_exists('statuses', $response['payment']) &&
        array_key_exists('status', $response['payment']['statuses']) &&
        count($response['payment']['statuses']['status']) > 0
    ) {
        $note .= '';

        try{
            foreach ($response['payment']['statuses'] as $status) {
                foreach ($status as $message) {
                    if ($with_code) {
                        $note .= '- ' . $message['code'] . ', ' . $message['description'] . '<br>';
                    }
                    else {
                        $note .= $message['description'] . '<br>';
                    }
                }
            }

            if (str_contains($note, 'The Requested Amount exceeds')) {
                $note = "The requested amount exceeds the initial transaction amount. This operation has already been completed.";
            }
        } catch (Exception $e) {
            $note = "Error on response";
        }
    }

    return $note;
}
