<?php

/**
 *
 * Copyright © 2023 PagoNxt Merchant Solutions S.L. German Branch
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0
 *
 */

namespace App\GetNetRedirect;

use App\Constants;

class WcOrderCaptureAuthorizationPayload
{
    /**
     * Retrieve the payload for cancellation
     *
     * @return array
     */
    public static function getPayload(
        $order,
        $settings,
        $processedBy,
        $purchaseRequestId,
        $purchasePaymentMethod,
        $purchaseTransactionType,
        $merchantAccountId,
        $transactionId
    ) {
        $payload = [];
        $requestId = current_time('YmdHis') . $order->get_id();
        $transactionType = Constants::TX_CAPTURE_AUTHORIZATION;

        $payload['payment'] = [
            'merchant-account-id' => [
                'value' => $merchantAccountId
            ],
            'shop' => [
                'system-name' => "wordpress-pagos",
                'system-version' => \WC_VERSION,
                'plugin-name' => "wc-getnet-redirect",
                'plugin-version' => "1.1.3",
                'integration-type' => "redirect"
            ],
            'request-id' => $requestId,
            'transaction-type' => $transactionType,
            'parent-transaction-id' => $transactionId,
            'payment-methods' => [
                'payment-method' => [
                    ['name' => $purchasePaymentMethod]
                ]
            ]
        ];

        if (
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_RATEPAY_ELV ||
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_RATEPAY_INVOICE
        ) {
            $orderItems = [];
            foreach ($order->get_items() as $item) {
                $unitPrice = round($item->get_total() / $item->get_quantity(), 2);
                $unitTax = round($item->get_subtotal_tax() / $item->get_quantity(), 2);
                $taxRate = round($unitTax / $unitPrice, 2);
                $itemInfo = [
                    'amount' => [
                        'currency' => $order->get_currency(),
                        'value' => $unitPrice + $unitTax,
                    ],
                    'article-number' => $item->get_product_id(),
                    'description' => null,
                    'name' => $item->get_name(),
                    'quantity' => $item->get_quantity(),
                    'tax-amount' => [
                        'currency' => $order->get_currency(),
                        'value' => $item->get_subtotal_tax(),
                    ],
                    'tax-rate' => $taxRate,
                ];
                $orderItems[] = $itemInfo;
            }

            if ($order->get_shipping_total() > 0) {
                $orderItems[] = [
                    'amount' => [
                        'currency' => $order->get_currency(),
                        'value' => $order->get_shipping_total()
                    ],
                    'article-number' => "SHIPPING",
                    'description' => "SHIPPING",
                    'name' => "SHIPPING",
                    'quantity' => 1,
                    'tax-amount' => [
                        'currency' => $order->get_currency(),
                        'value' => 0
                    ],
                    'tax-rate' => 0
                ];
            }
            $payload['payment']['order-items']['order-item'] = $orderItems;

            $payload['payment']['requested-amount'] = [
                'value' => $order->get_total(),
                'currency' => $order->get_currency(),
            ];
        }

        return $payload;
    }
}
