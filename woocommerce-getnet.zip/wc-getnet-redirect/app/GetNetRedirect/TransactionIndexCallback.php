<?php

/**
 *
 * Copyright © 2023 PagoNxt Merchant Solutions S.L. German Branch
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0
 *
 */

namespace App\GetNetRedirect;

use App\Models\Transaction;
use App\Constants;

class TransactionIndexCallback
{
    public function __construct()
    {
        //
    }

    public function show()
    {
        session_start();
        
        if(isset($_SESSION['message'])){
            $message = $_SESSION['message'];
            $code = $_SESSION['code'];

            if($code == Constants::TX_STATE_SUCCESS){
                echo '<div style="
                        color: #3c763d;
                        background-color: #dff0d8;
                        border-color: #d6e9c6;
                        padding: 15px;
                        margin-top: 20px;
                        border: 1px solid transparent;
                        border-radius: 4px;
                    ">Action performed successfully</div>';
            }
            else{
                echo '<div style="
                        color: #a94442;
                        background-color: #f2dede;
                        border-color: #ebccd1;
                        padding: 15px;
                        margin-top: 20px;
                        border: 1px solid transparent;
                        border-radius: 4px;
                    ">' . $message . '</div>';
            }
        }
        
        session_destroy();

        $results = Transaction::all();
        echo "
            <div class=\"wrap\">
                <h1>Transactions</h1>
                <table>
                    <tr>
                        <th>Order ID</th>
                        <th>Transaction ID</th>
                        <th>Payment Method</th>
                        <th>Transaction Type</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th></th>
                    </tr>
                    <tbody>
        ";
        $idRow = 0;
        foreach ($results as $row) {
            $order = \WC_Order_Factory::get_order($row->order_id);
            $detailUrl = "?page=gnr_detail&tx_id=" . $row->id;
            echo "
                <tr id=\"getnet-txs-row-" . $idRow . "\">
                    <td>
                        <a href=\"{$order->get_edit_order_url()}\">
                            {$row->order_id}
                        </a>
                    </td>
                    <td>{$row->transaction_id}</td>
                    <td>{$row->payment_method}</td>
                    <td id=\"getnet-txs-row-" . $idRow . "-type\">{$row->last_transaction_type}</td>
                    <td>{$row->created_at}</td>
                    <td>{$row->updated_at}</td>
                    <td>
                        <a id=\"getnet-txs-row-" . $idRow . "-edit\" href=\"{$detailUrl}\">
                            " . __('Edit') . "
                        </a>
                    </td>
                </tr>
            ";
            $idRow++;
        }
        echo "
                </tbody>
            </table>
        </div>";
    }
}
