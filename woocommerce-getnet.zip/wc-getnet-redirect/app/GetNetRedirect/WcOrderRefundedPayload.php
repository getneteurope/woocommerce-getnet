<?php

/**
 *
 * Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U.
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0
 *
 */

namespace App\GetNetRedirect;

use App\Constants;

class WcOrderRefundedPayload
{
    /**
     * Retrieve the payload for cancellation
     *
     * @return array
     */
    public static function getPayload(
        $order,
        $settings,
        $processedBy,
        $purchaseRequestId,
        $purchasePaymentMethod,
        $purchaseTransactionType,
        $merchantAccountId,
        $transactionId
    ) {
        $payload = [];
        $requestId = current_time('YmdHis') . $order->get_id();
        $transactionType = null;

        // Transaction Type Logic
        switch ($purchasePaymentMethod) {
            case Constants::PURCHASE_METHOD_ALIPAY_XBORDER:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_DEBIT;
                }
                break;
            case Constants::PURCHASE_METHOD_BLIK:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_DEBIT;
                }
                break;
            case Constants::PURCHASE_METHOD_BIZUM:
                if ($purchaseTransactionType === Constants::TX_CAPTURE_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                break;
            case Constants::PURCHASE_METHOD_CREDITCARD:
                if ($purchaseTransactionType === Constants::TX_CAPTURE_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                if ($purchaseTransactionType === Constants::TX_PURCHASE) {
                    $transactionType = Constants::TX_REFUND_PURCHASE;
                }
                break;
            case Constants::PURCHASE_METHOD_IDEAL:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_MULTIBANCO:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_DEBIT;
                }
                break;
            case Constants::PURCHASE_METHOD_P24:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_REQUEST;
                }
                break;
            case Constants::PURCHASE_METHOD_PAYPAL:
                if ($purchaseTransactionType === Constants::TX_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_DEBIT;
                }
                if ($purchaseTransactionType === Constants::TX_CAPTURE_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                break;
            case Constants::PURCHASE_METHOD_POI_PIA:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_RATEPAY_ELV:
                if ($purchaseTransactionType === Constants::TX_CAPTURE_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                break;
            case Constants::PURCHASE_METHOD_RATEPAY_INVOICE:
                if ($purchaseTransactionType === Constants::TX_CAPTURE_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                break;
            case Constants::PURCHASE_METHOD_SEPA_CREDIT:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_SEPA_DIRECT_DEBIT:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_SOFORT:
                // NO SUPPORT
                break;
        }

        if ($transactionType === null) {
            throw new \Exception("Purchase payment method {$purchasePaymentMethod} is not supported for refund");
        }

        $payload['payment'] = [
            'merchant-account-id' => [
                'value' => $merchantAccountId
            ],
            'shop' => [
                'system-name' => "wordpress-pagos",
                'system-version' => \WC_VERSION,
                'plugin-name' => "wc-getnet-redirect",
                'plugin-version' => "1.1.2",
                'integration-type' => "redirect"
            ],
            'request-id' => $requestId,
            'transaction-type' => $transactionType,
            'parent-transaction-id' => $transactionId
        ];

        if (
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_ALIPAY_XBORDER ||
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_BLIK ||
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_RATEPAY_ELV ||
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_RATEPAY_INVOICE
        ) {
            $payload['payment']['requested-amount'] = [
                'value' => $order->get_total(),
                'currency' => $order->get_currency(),
            ];
        }

        if (
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_RATEPAY_ELV ||
            $purchasePaymentMethod === Constants::PURCHASE_METHOD_RATEPAY_INVOICE
        ) {
            $orderItems = [];
            foreach ($order->get_items() as $item) {
                $unitPrice = round($item->get_total() / $item->get_quantity(), 2);
                $unitTax = round($item->get_subtotal_tax() / $item->get_quantity(), 2);
                $taxRate = round($unitTax / $unitPrice, 2);
                $itemInfo = [
                    'amount' => [
                        'currency' => $order->get_currency(),
                        'value' => $unitPrice + $unitTax,
                    ],
                    'article-number' => $item->get_product_id(),
                    'description' => null,
                    'name' => $item->get_name(),
                    'quantity' => $item->get_quantity(),
                    'tax-amount' => [
                        'currency' => $order->get_currency(),
                        'value' => $item->get_subtotal_tax(),
                    ],
                    'tax-rate' => $taxRate,
                ];
                $orderItems[] = $itemInfo;
            }

            if ($order->get_shipping_total() > 0) {
                $orderItems[] = [
                    'amount' => [
                        'currency' => $order->get_currency(),
                        'value' => $order->get_shipping_total()
                    ],
                    'article-number' => "SHIPPING",
                    'description' => "SHIPPING",
                    'name' => "SHIPPING",
                    'quantity' => 1,
                    'tax-amount' => [
                        'currency' => $order->get_currency(),
                        'value' => 0
                    ],
                    'tax-rate' => 0
                ];
            }
            $payload['payment']['order-items']['order-item'] = $orderItems;
        }

        return $payload;
    }
}
