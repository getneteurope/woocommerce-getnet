<?php

/**
 *
 * Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U.
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0
 *
 */

namespace App\GetNetRedirect;

use App\Constants;

class WcOrderCreditPayload
{
    /**
     * Retrieve the payload for cancellation
     *
     * @return array
     */
    public static function getPayload(
        $order,
        $settings,
        $processedBy,
        $purchaseRequestId,
        $purchasePaymentMethod,
        $purchaseTransactionType,
        $merchantAccountId,
        $transactionId,
        $iban
    ) {
        $payload = [];
        $requestId = current_time('YmdHis') . $order->get_id();
        $transactionType = Constants::TX_CREDIT;

        $payload['payment'] = [
            'merchant-account-id' => [
                'value' => $merchantAccountId
            ],
            'request-id' => $requestId,
            'transaction-type' => $transactionType,
            'parent-transaction-id' => $transactionId,
            'shop' => [
                'system-name' => "wordpress-pagos",
                'system-version' => \WC_VERSION,
                'plugin-name' => "wc-getnet-redirect",
                'plugin-version' => "1.0.8",
                'integration-type' => "redirect"
            ],
            'requested-amount' => [
                'value' => $order->get_total(),
                'currency' => $order->get_currency(),
            ],
            'payment-methods' => [
                'payment-method' => [
                    ['name' => Constants::PURCHASE_METHOD_SEPA_CREDIT]
                ]
            ],
            'bank-account' => [
                "iban" => $iban
            ]
        ];

        return $payload;
    }
}
