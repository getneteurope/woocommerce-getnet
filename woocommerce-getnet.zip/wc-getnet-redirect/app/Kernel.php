<?php

/**
 *
 * Copyright © 2023 PagoNxt Merchant Solutions S.L. German Branch
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0
 *
 */

namespace App;

use App\GetNetRedirect\ActivationCallback;

class Kernel
{
    public static $instance;

    /**
     * Activation hook. Runs when the plugin is activated
     *
     * @return void
     */
    private function addActivationHook()
    {
        register_activation_hook(PLUGIN_FILE, function () {
            ActivationCallback::execute();
        });
    }

    /**
     * Adds the payment gateway to the list of gateways
     *
     * @return void
     */
    private function addPaymentGatewayToList()
    {
        add_filter('woocommerce_payment_gateways', function ($gateways) {
            $gateways[] = 'App\\GetNetRedirectGateway';
            return $gateways;
        });
    }

    /**
     * Initializes the plugin
     *
     * @return \App\Kernel
     */
    public static function init()
    {
        if (!isset(self::$instance)) {
            self::$instance = new Kernel();
            self::$instance->setup();
        }
        return self::$instance;
    }

    /**
     * Initializes the gateway
     *
     * @return void
     */
    private function iniatilizeGateway()
    {
        add_action(
            'plugins_loaded',
            function () {
                $plugin_rel_path = basename(dirname(dirname(__FILE__))) . '/languages';
                load_plugin_textdomain( 'wc-getnet-redirect', false, $plugin_rel_path );
                (new GetNetRedirectGateway());
            },
            11
        );
    }

    /**
     * Setups the plugin
     *
     * @return void
     */
    public function setup()
    {
        $this->addActivationHook();
        $this->addPaymentGatewayToList();
        $this->iniatilizeGateway();
    }
}
